<!DOCTYPE html>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<html lang="en">
<head>
  <title>Toko Online Batik</title>
  <link rel="icon" type="image/gif/png" href="asset/img/Title.png">