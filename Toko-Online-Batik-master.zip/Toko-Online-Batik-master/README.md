# Toko-Online-Batik
Toko Online Batik dengan Bootstrap + PHP + MySql

Langkah untuk dapat menggunakan Website ini :
1. Download atau clone repository.
2. Ekstrak file zip yang telah didownload pada direktori server
3. Ekstrak file database batiku.sql di phpmyadmin
4. Website siap digunakan.

Untuk melihat dashbord admin :
1. Akses ke www.namawebsite.com/admin dengan mengganti nama website sesuai dengan website milik anda.
2. Login dengan username : admin@gmail.com | password : admin
